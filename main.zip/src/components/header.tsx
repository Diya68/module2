
"use client"

import Link from "next/link";
import { Button } from "./ui/button";
import { HeartPulse, Menu, Stethoscope, CalendarDays, Pill, UserPlus, LogIn, LayoutDashboard } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "./ui/sheet";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const navLinks = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/appointments", label: "Appointments", icon: CalendarDays },
  { href: "/book-appointment", label: "Book Appointment", icon: Stethoscope },
  { href: "/prescriptions", label: "Prescriptions", icon: Pill },
];

export default function Header() {
  const pathname = usePathname();

  const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
    <Link href={href} passHref>
      <Button variant="ghost" className={cn("text-base", pathname === href ? "text-primary font-bold" : "")}>
        {children}
      </Button>
    </Link>
  );

  const MobileNavLink = ({ href, children, icon: Icon }: { href: string; children: React.ReactNode; icon: React.ElementType }) => (
    <SheetClose asChild>
      <Link href={href} passHref>
        <Button variant="ghost" className={cn("w-full justify-start text-lg gap-4", pathname === href ? "text-primary font-bold" : "")}>
          <Icon className="h-5 w-5" />
          {children}
        </Button>
      </Link>
    </SheetClose>
  );

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <HeartPulse className="h-6 w-6 text-primary" />
            <span className="font-bold font-headline text-lg">HealthTrack</span>
          </Link>
          <nav className="hidden items-center space-x-1 md:flex">
            {navLinks.map((link) => (
              <NavLink key={link.href} href={link.href}>{link.label}</NavLink>
            ))}
          </nav>
        </div>

        <div className="flex flex-1 items-center justify-end space-x-2">
          <div className="hidden md:flex">
            <NavLink href="/login">Login</NavLink>
            <Button asChild>
              <Link href="/register">Register</Link>
            </Button>
          </div>

          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[80vw]">
                <div className="flex flex-col h-full p-4">
                  <nav className="flex flex-col gap-4 mt-8">
                    {navLinks.map((link) => (
                      <MobileNavLink key={link.href} href={link.href} icon={link.icon}>{link.label}</MobileNavLink>
                    ))}
                  </nav>
                  <div className="mt-auto flex flex-col gap-4">
                     <SheetClose asChild>
                        <Link href="/login" passHref>
                            <Button variant="outline" className="w-full justify-start text-lg gap-4">
                                <LogIn className="h-5 w-5" />
                                Login
                            </Button>
                        </Link>
                    </SheetClose>
                     <SheetClose asChild>
                        <Link href="/register" passHref>
                            <Button className="w-full justify-start text-lg gap-4">
                                <UserPlus className="h-5 w-5" />
                                Register
                            </Button>
                        </Link>
                    </SheetClose>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
