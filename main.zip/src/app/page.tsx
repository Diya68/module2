import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Stethoscope, CalendarDays, Pill } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <section className="relative w-full h-[60vh] md:h-[70vh] flex items-center justify-center text-center bg-primary/10 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image 
            src="https://placehold.co/1920x1080.png"
            alt="Healthcare professionals"
            layout="fill"
            objectFit="cover"
            className="opacity-20"
            data-ai-hint="healthcare professional"
          />
           <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent"></div>
        </div>
        <div className="container px-4 md:px-6 z-10">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-headline font-bold tracking-tight text-primary sm:text-5xl md:text-6xl">
              Your Health, Simplified.
            </h1>
            <p className="mt-6 text-lg leading-8 text-foreground/80">
              Easily manage your medical appointments, view prescriptions, and take control of your healthcare journey with HealthTrack.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <Button asChild size="lg">
                <Link href="/book-appointment">Book an Appointment</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/login">Access Your Portal</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="py-12 sm:py-24 bg-background">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold font-headline tracking-tight text-center text-primary">
            A Better Way to Manage Your Health
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-center text-foreground/70">
            Our platform provides you with the tools you need to stay on top of your health.
          </p>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            <Card className="text-center transition-transform hover:scale-105 hover:shadow-xl">
              <CardHeader>
                <div className="mx-auto bg-primary/10 rounded-full p-4 w-fit">
                  <Stethoscope className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="font-headline mt-4">Easy Appointment Booking</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Find doctors and book your appointments in just a few clicks. No more waiting on the phone.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center transition-transform hover:scale-105 hover:shadow-xl">
              <CardHeader>
                <div className="mx-auto bg-primary/10 rounded-full p-4 w-fit">
                  <CalendarDays className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="font-headline mt-4">View Your Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Keep track of all your upcoming and past appointments in one organized place.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center transition-transform hover:scale-105 hover:shadow-xl">
              <CardHeader>
                <div className="mx-auto bg-primary/10 rounded-full p-4 w-fit">
                  <Pill className="h-10 w-10 text-primary" />
                </div>
                <CardTitle className="font-headline mt-4">Access Prescriptions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  View your current and past prescriptions anytime, anywhere.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
