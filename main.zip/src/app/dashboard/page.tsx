
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Pill, User } from "lucide-react";
import Link from "next/link";

const latestAppointment = {
    doctor: "Dr. Evelyn Reed",
    specialty: "Cardiologist",
    date: "2024-08-15",
    time: "10:00 AM",
};

const latestPrescription = {
    medication: "Lisinopril",
    dosage: "10mg",
    doctor: "Dr. Evelyn Reed",
};

export default function DashboardPage() {
  return (
    <div className="container mx-auto py-10">
        <div className="mb-8">
            <h1 className="text-3xl font-bold font-headline">Welcome back, User!</h1>
            <p className="text-muted-foreground">Here's a quick overview of your health dashboard.</p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card className="lg:col-span-2">
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle className="font-headline">Next Appointment</CardTitle>
                        <CardDescription>Your upcoming scheduled visit.</CardDescription>
                    </div>
                    <Calendar className="h-8 w-8 text-primary" />
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        <p className="text-lg font-semibold">Dr. {latestAppointment.doctor}</p>
                        <p className="text-muted-foreground">{latestAppointment.specialty}</p>
                        <p className="font-medium">{new Date(latestAppointment.date).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })} at {latestAppointment.time}</p>
                    </div>
                </CardContent>
                <div className="p-6 pt-0">
                    <Button asChild>
                        <Link href="/appointments">View All Appointments</Link>
                    </Button>
                </div>
            </Card>

            <Card>
                <CardHeader  className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle className="font-headline">Latest Prescription</CardTitle>
                        <CardDescription>Your most recent medication.</CardDescription>
                    </div>
                    <Pill className="h-8 w-8 text-primary" />
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        <p className="text-lg font-semibold">{latestPrescription.medication}</p>
                        <p className="text-muted-foreground">Dosage: {latestPrescription.dosage}</p>
                        <p className="text-sm">Prescribed by Dr. {latestPrescription.doctor}</p>
                    </div>
                </CardContent>
                <div className="p-6 pt-0">
                    <Button asChild variant="outline">
                        <Link href="/prescriptions">View All Prescriptions</Link>
                    </Button>
                </div>
            </Card>

            <Card className="flex flex-col items-center justify-center p-6 text-center">
                 <User className="h-12 w-12 text-primary" />
                <CardTitle className="font-headline mt-4">Your Profile</CardTitle>
                <CardDescription className="mt-2">View and manage your personal information.</CardDescription>
                <Button asChild className="mt-4">
                    <Link href="/register">Manage Profile</Link>
                </Button>
            </Card>

             <Card className="flex flex-col items-center justify-center p-6 text-center">
                 <Calendar className="h-12 w-12 text-primary" />
                <CardTitle className="font-headline mt-4">Book Appointment</CardTitle>
                <CardDescription className="mt-2">Find a doctor and schedule your next visit.</CardDescription>
                <Button asChild className="mt-4">
                    <Link href="/book-appointment">Book Now</Link>
                </Button>
            </Card>
        </div>
    </div>
  );
}
