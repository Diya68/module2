import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Pill } from "lucide-react";

const prescriptions = [
  {
    medication: "Lisinopril",
    dosage: "10mg",
    frequency: "Once daily",
    doctor: "Dr. Evelyn Reed",
    date: "2024-07-28",
  },
  {
    medication: "Metformin",
    dosage: "500mg",
    frequency: "Twice daily",
    doctor: "Dr. Alice Wong",
    date: "2024-07-25",
  },
  {
    medication: "Atorvastatin",
    dosage: "20mg",
    frequency: "Once daily at night",
    doctor: "Dr. Evelyn Reed",
    date: "2024-07-20",
  },
  {
    medication: "Amoxicillin",
    dosage: "250mg",
    frequency: "Every 8 hours for 7 days",
    doctor: "Dr. John Carter",
    date: "2024-06-10",
  },
];

export default function PrescriptionsPage() {
  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold font-headline">Your Prescriptions</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {prescriptions.map((p, index) => (
          <Card key={index} className="flex flex-col">
            <CardHeader className="flex flex-row items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-full">
                    <Pill className="h-6 w-6 text-primary" />
                </div>
                <div>
                    <CardTitle className="font-headline">{p.medication}</CardTitle>
                    <CardDescription>{p.dosage}</CardDescription>
                </div>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="font-medium">Frequency:</p>
              <p className="text-muted-foreground">{p.frequency}</p>
            </CardContent>
            <CardFooter className="text-sm text-muted-foreground">
                <p>Prescribed by {p.doctor} on {new Date(p.date).toLocaleDateString()}</p>
            </CardFooter>
          </Card>
        ))}
      </div>
      {prescriptions.length === 0 && (
        <div className="text-center py-20 rounded-lg border-2 border-dashed">
            <Pill className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-4 text-lg font-semibold">No Prescriptions Found</h3>
            <p className="mt-2 text-sm text-muted-foreground">Your prescribed medications will appear here.</p>
        </div>
      )}
    </div>
  );
}
